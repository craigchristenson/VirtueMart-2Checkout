<?php
defined('_JEXEC') or die('Restricted access');

if (!class_exists('VmConfig')) {
  require(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_virtuemart' . DS . 'helpers' . DS . 'config.php');
}
if (!class_exists('ShopFunctions')) {
  require(VMPATH_ADMIN . DS . 'helpers' . DS . 'shopfunctions.php');
}


/**
 * Renders a multiple item select element
 *
 */
JFormHelper::loadFieldClass('list');
jimport('joomla.form.formfield');

class JFormFieldTco extends JFormFieldList {

  protected function getOptions() {
    return parent::getOptions();
  }

}
